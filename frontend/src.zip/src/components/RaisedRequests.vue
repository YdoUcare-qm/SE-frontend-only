<template>
    <div>
      <!-- Heading -->
      <h2>Requests</h2>
  
      <!-- Request Items -->
      <div class="request-list">
        <!-- Loop through request items and display each as a dialog box -->
        <div v-for="(request, index) in requests" :key="index" class="request-item">
          <div class="dialog-box">
            <!-- Request Name -->
            <p>{{ request.name }}</p>
            <!-- Date -->
            <p class="date">{{ formatDate(request.date) }}</p>
            <!-- Action Buttons (Approve, Reject) -->
            <div class="action-buttons">
              <button @click="approveRequest(request)" class="approve-button">Approve</button>
              <button @click="rejectRequest(request)" class="reject-button">Reject</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "RaisedRequests",
    data() {
      return {
        requests: [
          { id: 1, name: "Support staff 45 requests new tag", date: "2024-04-14" },
          { id: 2, name: "FaQ requests", date: "2024-04-15" },
          // Add more request items as needed
        ]
      };
    },
    methods: {
      formatDate(date) {
        // Format date (e.g., "YYYY-MM-DD" to "DD/MM/YYYY")
        const [year, month, day] = date.split("-");
        return `${day}/${month}/${year}`;
      },
      approveRequest(request) {
        // Implement approve request logic
        console.log("Approving request:", request.name);
      },
      rejectRequest(request) {
        // Implement reject request logic
        console.log("Rejecting request:", request.name);
      }
    }
  };
  </script>
  
  <style scoped>
  /* Request List Styles */
  .request-list {
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  
  .request-item {
    margin-top: 20px;
  }
  
  /* Dialog Box Styles */
  .dialog-box {
    width: 400px;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    background-color: #fff;
  }
  
  .dialog-box p {
    margin: 0;
  }
  
  .date {
    font-size: 14px;
    color: #666;
  }
  
  .action-buttons {
    display: flex;
    justify-content: flex-end;
    margin-top: 10px;
  }
  
  .approve-button,
  .reject-button {
    margin-left: 10px;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  .approve-button {
    background-color: #4caf50;
    color: #fff;
  }
  
  .reject-button {
    background-color: #f44336;
    color: #fff;
  }
  </style>
  