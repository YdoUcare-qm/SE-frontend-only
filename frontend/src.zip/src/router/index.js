import { createWebHistory, createRouter } from 'vue-router';
import ChangePasswordComponent from '../components/ChangePasswordComponent.vue';
import LoginComponent from '../components/LoginComponent.vue';
// import DashboardStudentComponent from '../components/DashboardStudentComponent.vue';
import dash_board from '../components/Dashboard.vue';
// import DashboardAdminComponent from '../components/DashboardAdminComponent.vue';
// import DashboardSupportAgentComponent from '../components/DashboardSupportAgentComponent.vue';
import AddTicketComponent from '../components/AddTicketComponent.vue';
import EditTicketComponent from '../components/EditTicketComponent.vue';
import AllTicketComponent from '../components/AllTicketComponent.vue';
import ResponseComponent from '../components/ResponseComponent.vue';
import ManageUsersComponent from '../components/ManageUsersComponent.vue';
import ManageFAQSuggestionsComponent from '../components/ManageFAQComponent.vue';
import ManageFlaggedPosts from '../components/ManageFlaggedPosts.vue';
import AddAdminsComponent from '../components/AddAdmins.vue';
import UserComponent from '../components/UserComponent.vue';
import SettingsComponent from '../components/SettingsComponent.vue';
import SubscriptionComponent from '../components/SubscriptionComponent.vue';
import NotificationComponent from '../components/NotificationComponent.vue';
import ThreadComponent from '../components/ThreadComponent.vue'
import FrequentlyComponent from '../components/FrequentlyComponent.vue'
import ThreadMangementComponent from '../components/ThreadMangementComponent.vue'
import SupportProfile from '../components/SupportProfile.vue'
import SupportChat from '../components/SupportChat.vue'
import SupportStaffManagement from '../components/SupportStaffManagement.vue';
import UserManagement from '../components/UserManagement.vue';
import RaisedRequests from '../components/RaisedRequests.vue';
import RegistrationComponent from '@/components/RegistrationComponent.vue';
import AdminDashboard from '../components/AdminDashboard.vue';
// import store from "../store";
const routes = [
    {
        path: "/",
        component: LoginComponent,
    },
    {
        path: "/AdminDashboard",
        component: AdminDashboard,
    },
    {
        path: "/register",
        component: RegistrationComponent,
    },
    {
        path: "/changePassword",
        component: ChangePasswordComponent,
    },
    {
        path: "/dashboard",
        component: dash_board,
    },
    {
        path: "/addTicket",
        component: AddTicketComponent,
    },
    {
        name: "editTicket",
        path: "/editTicket/:ticketId",
        component: EditTicketComponent,
        props: true
    },
    {
        path: "/allTicket",
        component: AllTicketComponent,
    },
    {
        path: "/response/:ticketId",
        component: ResponseComponent,
        name: "response",
        props: true
    },
    {
        path: "/manageUsers",
        component: ManageUsersComponent,
        name: "manageUsers"

    },
    {
        path: "/manageFAQ",
        component: ManageFAQSuggestionsComponent,
        name: "manageFAQ"
    },
    {
        path: "/manageFlaggedPosts",
        component: ManageFlaggedPosts,
        name: "manageFlaggedPosts"
    },
    {
        path: "/addAdmins",
        component: AddAdminsComponent,
        name: "AddAdmins"
    },
    {
        path: "/UserComponent",
        component: UserComponent,
    },
    {
        path: "/SettingsComponent",
        component: SettingsComponent,
    },
    {
        path: "/SubscriptionComponent",
        component: SubscriptionComponent,
    },
    {
        path: "/NotificationComponent",
        component: NotificationComponent,
    },
    {
        path: "/ThreadComponent",
        component: ThreadComponent,
    },
    {
        path: "/FrequentlyComponent",
        component: FrequentlyComponent,
    },
    {
        path: "/SupportProfile",
        component: SupportProfile,
    },
    {
        path: "/ThreadManagementComponent",
        component: ThreadMangementComponent,
    },
    {
        path: "/SupportChat",
        component: SupportChat,
    },
    {
        path: "/SupportStaffManagement",
        component: SupportStaffManagement,

    },

    {
        path: "/UserManagement",
        component: UserManagement,

    },

    {
        path: "/Requests",
        component: RaisedRequests,

    }
];
const router = createRouter({
    history: createWebHistory(),
    routes: routes,
});

export default router;
